# Consumer - EHDS Logical Information Models v1.0.0

## ActorDefinition: Consumer 



## Resource Content

```json
{
  "resourceType" : "ActorDefinition",
  "id" : "actor-consumer",
  "url" : "https://www.xt-ehr.eu/specifications/fhir/actor-consumer",
  "version" : "1.0.0",
  "name" : "Consumer",
  "status" : "active",
  "date" : "2026-05-08T08:22:22+00:00",
  "publisher" : "Xt-EHR",
  "contact" : [{
    "name" : "Xt-EHR",
    "telecom" : [{
      "system" : "url",
      "value" : "http://www.xt-ehr.eu/"
    }]
  }],
  "type" : "system"
}

```
